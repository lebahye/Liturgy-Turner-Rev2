# Armenian Liturgy Turner

## Overview

This is a full-stack web application designed to help with Armenian liturgy page turning during services. The system allows users to upload liturgy PDFs, train the application by marking page transitions synchronized with audio recordings, and then use live audio matching to automatically advance pages during services. It features a separate display mode for projection screens.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: Zustand with persistence middleware for global app state
- **Data Fetching**: TanStack React Query for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS v4 with custom CSS variables for theming
- **PDF Rendering**: react-pdf library with PDF.js worker
- **Audio Processing**: Meyda library for audio feature extraction (MFCC, spectral analysis)
- **Build Tool**: Vite with custom plugins for Replit integration

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript compiled with tsx
- **API Pattern**: RESTful endpoints under `/api/` prefix
- **File Uploads**: Multer middleware for handling PDF and audio file uploads
- **Static Files**: Serves uploaded files from `client/public/uploads/`

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` (shared between frontend and backend)
- **Tables**:
  - `users` - Basic user authentication
  - `uploaded_files` - Tracks uploaded PDFs and audio files
  - `training_sessions` - Stores training session metadata (PDF path, audio path, page count)
  - `page_markers` - Stores timestamp and audio feature data for each page transition
  - `aggregated_fingerprints` - Combines audio fingerprints from multiple training sessions per page for improved accuracy
  - `page_transcripts` - Stores extracted text from each PDF page for speech-to-text matching

### Key Features
- **Training Mode**: Record audio while manually marking page transitions. Captures audio fingerprints (RMS, ZCR, spectral centroid, rolloff, MFCC) at each page turn marker using Meyda library. Each training session automatically merges with previous sessions for improved accuracy.
- **Multi-Session Learning**: System improves with repeated training (3+ sessions recommended). Aggregated fingerprints store averaged features from all sessions, with confidence scores based on session count and feature consistency.
- **Training Audio Transcription**: Uses ffmpeg to extract audio segments for each page (based on page marker timestamps) and Gemini AI to transcribe the actual sung words. This enhances page transcripts with what's actually sung (not just what's written in the PDF).
- **Speech-to-Text Matching (Primary)**: Uses Gemini AI to transcribe live audio in 5-second chunks. Compares transcriptions against stored page transcripts using Levenshtein distance for fuzzy word matching. Page transcripts combine PDF-extracted text AND training audio transcriptions for maximum accuracy.
- **Live Mode**: Real-time speech-to-text analysis compares live microphone audio against stored page transcripts. Automatically advances pages when text match confidence exceeds 50% and page is ahead of current position. Also supports manual controls (Space for next page, B for previous).
- **Display Mode**: Full-screen PDF display designed for projection, listens for page changes from the main app via WebSocket
- **PDF Text Extraction**: Automatically extracts Armenian text from PDF pages to create reference transcripts for speech matching. Supports both Armenian script and transliterated text.
- **Audio Visualization**: Real-time waveform display using Canvas API
- **Data Persistence**: Training sessions, page markers, and page transcripts stored in PostgreSQL database

### API Endpoints for Training Audio Processing
- `GET /api/audio-files` - List available training audio recordings
- `POST /api/process-training-audio` - Process a training recording to learn sung words per page
  - Requires: `audioPath`, `pdfPath`, optional `startPage`/`endPage`
  - Uses page marker timestamps to segment audio
  - Transcribes each segment with Gemini AI
  - Stores transcriptions alongside PDF text for improved matching

### Build System
- **Development**: Vite dev server with HMR on port 5000
- **Production**: Custom build script using esbuild for server bundling, Vite for client
- **Output**: Compiled to `dist/` directory with server as `index.cjs` and client assets in `dist/public/`

## External Dependencies

### Database
- PostgreSQL database (connection via `DATABASE_URL` environment variable)
- Drizzle Kit for schema migrations (`npm run db:push`)

### Third-Party Libraries
- **react-pdf**: PDF rendering in browser
- **Meyda**: Audio feature extraction for music/audio analysis
- **multer**: File upload handling
- **connect-pg-simple**: PostgreSQL session storage (available but session management not fully implemented)

### File Storage
- Uploaded files stored locally in `client/public/uploads/` directory
- PDFs in `uploads/pdfs/`
- Audio recordings in `uploads/audio/`